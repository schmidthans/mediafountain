##Spankbang Module by mediafountain 2015-05
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,sys,main,xbmc,os,cgi
import urlresolver

from t0mm0.common.net import Net
net = Net()

artwork = main.artwork
base_url = 'http://spankbang.com'
settings = main.settings

def CATEGORIES():
        main.addDir('Genres','none','spankbangGenres',artwork + '/main/genres.png')
        main.addDir('Newest',base_url +'/new_videos/','spankbangIndex',artwork + '/main/featured.png')
        main.addDir('Search','none','spankbangSearch',artwork + '/main/search.png')

def GENRES():
    url = base_url + '/categories'
    link = net.http_GET(url).content
    #match=re.compile('<h2>Categories</h2>(.+?)<div class="sep"></div>', re.S).findall(link)
    #print "eliinfo match", match[0]
    genre=re.compile('<a href="(/category/.+?)"><img src="(.+?)"><span>(.+?)</span></a>', re.S).findall(link)
    if genre:
        for (phUrl, phThumb, phTitle) in genre:
            #print "#### phUrl, phThumb, phTitle"+phUrl, phThumb, phTitle
            #print "########### phUrl"+phUrl
            url = base_url + phUrl
            phThumb = base_url + phThumb
            #print "eliinfo ######### genre", url, phTitle, phThumb
            try: 
                main.addDir(phTitle,url,'spankbangIndex',phThumb)
            except:
                continue

def INDEX(url):
        print "###### get INDEX url:"+url
        next_page = ''
        if re.match(".*?/s/", url):
            issearch=True
        else:
            issearch=False
        link = net.http_GET(url).content
        #print "eliinfo ############### INDEX link", re.compile('<(.+?)>',re.S).findall(link)
        match=re.compile('<div class="video-item".+?<a href="(.+?)".+?<img src="(.+?)".*?title="(.+?)"',re.S).findall(link)
        np=re.compile('<span class="status">page.+?<a href="(.+?)" class="next">Next page', re.S).findall(link)
        #print "eliinfo ######### INDEX np", np
        main.addDir('[COLOR blue]Set filter[/COLOR]',url,'spankbangFilter',artwork + '/main/next.png')
        if len(np) > 0:
                next_page = base_url + np[0]
                print "############## nestpage ="+next_page
                #http://www.spankbang.tv/en/search_results.html?search=%s&page=%s
                #print "eliinfo ######### INDEX next_page", next_page
                if settings.getSetting('nextpagetop') == 'true':
                        main.addDir('[COLOR blue]Next Page[/COLOR]',next_page,'spankbangIndex',artwork + '/main/next.png')
        if match:
            #print "elinfo ############ INDEX match", match
            for url,thumbnail,name in match:
                name=name.encode('utf-8')
                url = base_url + url
                #if issearch: http://cdnthumb3.spankbang.com/360/2/6/269834-t6.jpg
                thumbnail="http://"  + thumbnail
                    #print "eliinfo ######### INDEX thumbnail"
                #print "elinfo ############ INDEX url,name,thumbnail", url,name,thumbnail
                try: 
                    main.addDir(name,url,'spankbangVideoLinks',thumbnail)
                except:
                    continue
        if len(np) > 0:
                if settings.getSetting('nextpagebottom') == 'true':
                        main.addDir('[COLOR blue]Next Page[/COLOR]',next_page,'spankbangIndex',artwork + '/main/next.png')
        main.AUTOVIEW('movies')

def VIDEOLINKS(name,url,thumb):
        print "elinfo ############ VIDEOLINKS url", url
        link = net.http_GET(url).content
        #print "elinfo ############ VIDEOLINKS link", link.encode('utf-8')
        stream_quality=re.findall('<span class="ft-button ft-light-blue tt q_(.+?)"', link)
        print "### found yualitis",stream_quality
        #stream_quality=re.search("var stream_quality\s+=\s+'(.+?)';", link)
        stream_id=re.search("var stream_id\s+=\s+'(.+?)';", link)
        stream_key=re.search("var stream_key\s+=\s+'(.+?)';", link)
        if stream_quality and stream_id and stream_key:
            print "##### found"+stream_quality[0],stream_id.group(1), stream_key.group(1)
            url= 'http://spankbang.com/_%s/%s/title/%s__mp4' % (stream_id.group(1), stream_key.group(1), stream_quality[0])
            print "##### dataurl", url
            try:
#http://higgsboson15.spankbang.com/2/6/269834-hi.mp4
                main.RESOLVE(name,url,thumb)
                #main.addHDir(name,url,'resolve',thumb)
            except:
                pass
#         linkdata = net.http_GET(dataurl).content
#         print "elinfo ############ VIDEOLINKS link", linkdata.encode('utf-8')
#         if match:
#             url = base_url + match[0]
#             print "VIDEOLINKS final ########url", url
#             if main.resolvable(url):
#                 try:
#                 #http://higgsboson15.spankbang.com/2/6/269834-hi.mp4
#                     main.addHDir(name,url,'resolve',thumb)
#                 except:
#                     pass

def FILTER(url):
        url = url + '?length=long'
        print "###### new filterurl="+url
        INDEX(url)

def SEARCH():
        search = ''
        keyboard = xbmc.Keyboard(search,'Search')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search = keyboard.getText()
                search = re.sub(' ','+', search)
                url = base_url + '/s/' + search
                INDEX(url)