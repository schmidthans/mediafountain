##mykino Module by mediafountain 2015-05
import urllib,urllib2,re,xbmcplugin,xbmcgui,xbmcaddon,sys,main,xbmc,os,cgi
import urlresolver

from t0mm0.common.net import Net
net = Net()

artwork = main.artwork
base_url = 'http://mykino.to'
settings = main.settings

def CATEGORIES():
        main.addDir('Kinofilme',base_url +'/aktuelle-kinofilme','mykinoIndex',artwork + '/main/kino.png')
        main.addDir('Neue Filme',base_url +'/filme/','mykinoIndex',artwork + '/main/featured.png')
        main.addDir('Genres','none','mykinoGenres',artwork + '/main/genres.png')
        main.addDir('Search','none','mykinoSearch',artwork + '/main/search.png')

def GENRES():
    url = base_url
    link = net.http_GET(url).content
    #match=re.compile('<h2>Categories</h2>(.+?)<div class="sep"></div>', re.S).findall(link)
    #print "eliinfo match", match[0]
    parse=re.search('<div class="contab" id="tabln1">(.+?)</div>', link, re.S)
    print "### parse", parse.group(1).encode('utf-8')
    genre=re.compile('<li><a href="(.+?)">(.+?)</a></li>', re.S).findall(parse.group(1))
    if genre:
        for (phUrl, phTitle) in genre:
            #print "#### phUrl, phThumb, phTitle"+phUrl, phThumb, phTitle
            #print "########### phUrl"+phUrl
            url = base_url + phUrl
            #phThumb = base_url + phThumb
            print "eliinfo ######### genre", url, phTitle.encode('utf-8')
            try: 
                main.addDir(phTitle.encode('utf-8'),url,'mykinoIndex','none')
            except:
                continue

def INDEX(url):
        print "###### get INDEX url:",url
        next_page = ''
        print '### type(url)',type(url)
        if re.match("http", url):
            issearch=False
        else:
            issearch=True
        if issearch:
             print "#### is search", url
             urlparts = url.split('#')
             print "#### is search0", urlparts[0]
             print "#### is search1", urlparts[1]
             search_start = urlparts[1]
             result_from = str(int(urlparts[1])*10+1)
             dataPost = {'do':'search','subaction':'search','story':urlparts[0], 'search_start':search_start, 'result_from':result_from}
             link=net.http_POST(base_url+'/index.php', dataPost).content
        else:
             link = net.http_GET(url).content
        match=re.compile('<div class="boxgrid2 caption2">\n<a href="(.+?.html)">\n<img class="images3" src="(.+?)".*?<div class="boxgridtext">\n(.+?)\n</div>',re.S).findall(link)
        if issearch:
            np=re.compile('<div class="pagenavigation ">.+?onclick="javascript:list_submit\((\d+?)\); return\(false\)" href="#">Weiter</a>', re.S).findall(link)
            print "#### search nextpage", np[0]
            print "#### search nextpage" , str(int(np[0])*10+1)
            next_page = urlparts[0] + "#" + np[0]
        else:
            np=re.compile('<div class="pagenavigation ">.+?</a><a href="(.+?)">Weiter', re.S).findall(link)
            next_page = np[0]
        #print "eliinfo ######### INDEX np", np
        if len(np) > 0:
                print "############## nestpage =",next_page
                if settings.getSetting('nextpagetop') == 'true':
                        main.addDir('[COLOR blue]Next Page[/COLOR]',next_page,'mykinoIndex',artwork + '/main/next.png')
        if match:
            #print "elinfo ############ INDEX match", match
            for url,thumbnail,name in match:
                name=name.encode('utf-8')
                try: 
                    main.addDir(name,url,'mykinoVideoLinks',thumbnail)
                except:
                    continue
        if len(np) > 0:
                if settings.getSetting('nextpagebottom') == 'true':
                        main.addDir('[COLOR blue]Next Page[/COLOR]',next_page,'mykinoIndex',artwork + '/main/next.png')
        main.AUTOVIEW('movies')

def VIDEOLINKS(name,url,thumb):
        print "### VIDEOLINKS", name,url,thumb
        link = net.http_GET(url).content
        match1=re.compile('data-href="(.+?)".*?<span>(.+?)</span>', re.S).findall(link)
        for urls,hoster in match1:
            print "### url,hoster",url,hoster
            #Hoster = Hoster.replace('www.','')
            streams = urls.split("#,")
            if streams:
                for url in streams:
                    #url = "%s/en/out/%s" % (base_url, url)
                    print "### addHdir",name, url, hoster,'resolve',thumb
                    main.addHDir(name, url,'resolve',thumb)

def FILTER(url):
        url = url + '?length=long'
        print "###### new filterurl="+url
        INDEX(url)

def SEARCH():
        search = ''
        keyboard = xbmc.Keyboard(search,'Search')
        keyboard.doModal()
        if keyboard.isConfirmed():
                search = keyboard.getText()
                search = re.sub(' ','+', search)
                #url = base_url + '/s/' + search
                url = search+"#"+'0'
                INDEX(url)

def MASTERSEARCH(search):
        url = search+"#"+'0'
        INDEX(url)